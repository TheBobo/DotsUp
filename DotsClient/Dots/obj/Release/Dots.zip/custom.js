$(document).ready(function () {

    windowWidth = $(document).width();
    windowWidth = windowWidth - 10;

    $(".table").css("width", windowWidth);
    $(".table").css("margin-left", 5);

    if (windowWidth < 767) {
        $("#rows").css("width", "100%");
        $("#cols").css("width", "100%");
        $("#create").css("width", "100%");

    }

    $(document).on("click", "#create", function () {
        var rows = parseInt($("#rows").val());
        var cols = parseInt($("#cols").val());


        buildTable(rows, cols);

    });

    $(document).on("click", ".line", function () {
        $(this).css("opacity", 1);
        $(this).attr("data-isSelected", 1);
        if (!CloseBox(this)) {
            if (player == player1) {
                player = player2;
            }
            else {
                player = player1;
            }
        }

    });
});

var math = {
    add: function addTwoNumbers(a, b) {
        return a + b;
    },

    substract: function substractTwoNumbers(a, b) {
        return a - b;
    },

    product: function productTwoNumbers(a, b) {
        return a * b;
    },

    devide: function devideTwoNumbers(a, b) {
        return a / b;
    }


};

var tbRow = 0, tbCol = 0, player1 = "#44aa66", player2 = "#440066", player = player1;
var windowWidth = 400;

function buildTable(row, col) {
    tbRow = row;
    tbCol = col;
    debugger;
    var objWidth = (windowWidth - (3 * row)) / row;
    var width5percent = windowWidth / 100 * 5;
    $("#createTableForm").hide();
    var result = "";
    for (var i = 0; i < 2 * row + 1; i++) {
        for (var j = 0; j < 2 * col + 1; j++) {


            if (i % 2 == 0 && j % 2 == 0) {
                var left = (parseInt(j / 2) * objWidth);
                var top = (parseInt(i / 2) * objWidth);
                result += "<div class='dot' style='border-radius:" + objWidth + "px; width: " + width5percent + "px; height:" + width5percent + "px; left: " + left + "px; top:" + top + "px;' data-i='" + i + "' data-j='" + j + "'></div>"
            }
            else if (i % 2 == 1 && j % 2 == 0) {

                var left = (parseInt(j / 2) * objWidth);
                var top = (parseInt(i / 2) * objWidth) + 3;
                result += "<div class='line vertical' style='border-radius:" + objWidth + "px; height:" + (objWidth + width5percent) + "px; width:" + width5percent + "px; left: " + left + "px; top:" + (top - 3) + "px;' data-i='" + i + "' data-j='" + j + "' data-isHorizontal='0' data-isSelected='0' data-id='" + i + "_" + j + "' ></div>";
            }
            else if (i % 2 == 0 && j % 2 == 1) {
                var left = (parseInt(j / 2) * objWidth) + 3;
                var top = (parseInt(i / 2) * objWidth);
                result += "<div class='line horizontal' style='border-radius:" + objWidth + "px; width:" + (objWidth + width5percent) + "px; height:" + width5percent + "px; left: " + (left - 3) + "px; top:" + top + "px;' data-i='" + i + "' data-j='" + j + "' data-isHorizontal='1' data-isSelected='0' data-id='" + i + "_" + j + "'></div>"
            }
            else if (i % 2 == 1 && j % 2 == 1) {
                var left = (parseInt(j / 2) * objWidth) + width5percent;
                var top = (parseInt(i / 2) * objWidth) + width5percent;
                result += "<div class='box ' style='width:" + (objWidth - width5percent - 2) + "px; height:" + (objWidth - width5percent - 2) + "px; left: " + (left) + "px; top:" + (top) + "px;' data-i='" + i + "+' data-j='" + j + "' data-id='" + i + "_" + j + "'></div>"
            }
        }
    }
    result += "<div class='clear'></div>"
    $(".table").html(result)
}

function CloseBox(item) {
    var row = parseInt($(item).attr("data-i"));
    var col = parseInt($(item).attr("data-j"));
    var isHorizontal = $(item).attr("data-isHorizontal");

    if (isHorizontal == 1) {
        if (row == 0) {
            var checkIdUp = (row + 2) + "_" + col;
            var checkIdLeft = (row + 1) + "_" + (col - 1);
            var checkIdRight = (row + 1) + "_" + (col + 1);
            if ($(".line[data-id=" + checkIdUp + "]").attr("data-isSelected") == 1 &&
               $(".line[data-id=" + checkIdLeft + "]").attr("data-isSelected") == 1 &&
               $(".line[data-id=" + checkIdRight + "]").attr("data-isSelected") == 1) {
                var checkIdColor = (row + 1) + "_" + (col);
                $(".box[data-id=" + checkIdColor + "]").css("opacity", 1);
                $(".box[data-id=" + checkIdColor + "]").css("background-color", player);
                return true;
            }
            return false;
        }
        else if (row == tbRow * 2 + 1) {
            var checkIdUp = (row - 2) + "_" + col;
            var checkIdLeft = (row - 1) + "_" + (col - 1);
            var checkIdRight = (row - 1) + "_" + (col + 1);
            if ($(".line[data-id=" + checkIdUp + "]").attr("data-isSelected") == 1 &&
               $(".line[data-id=" + checkIdLeft + "]").attr("data-isSelected") == 1 &&
               $(".line[data-id=" + checkIdRight + "]").attr("data-isSelected") == 1) {
                var checkIdColor = (row - 1) + "_" + (col);
                $(".box[data-id=" + checkIdColor + "]").css("opacity", 1);
                $(".box[data-id=" + checkIdColor + "]").css("background-color", player);
                return true;
            }
            return false;
        }
        else {
            var result = false;
            var checkIdUp = (row - 2) + "_" + col;
            var checkIdLeft = (row - 1) + "_" + (col - 1);
            var checkIdRight = (row - 1) + "_" + (col + 1);
            if ($(".line[data-id=" + checkIdUp + "]").attr("data-isSelected") == 1 &&
               $(".line[data-id=" + checkIdLeft + "]").attr("data-isSelected") == 1 &&
               $(".line[data-id=" + checkIdRight + "]").attr("data-isSelected") == 1) {
                var checkIdColor = (row - 1) + "_" + (col);
                $(".box[data-id=" + checkIdColor + "]").css("opacity", 1);
                $(".box[data-id=" + checkIdColor + "]").css("background-color", player);
                result = true;
            }

            checkIdUp = (row + 2) + "_" + col;
            checkIdLeft = (row + 1) + "_" + (col - 1);
            checkIdRight = (row + 1) + "_" + (col + 1);
            if ($(".line[data-id=" + checkIdUp + "]").attr("data-isSelected") == 1 &&
               $(".line[data-id=" + checkIdLeft + "]").attr("data-isSelected") == 1 &&
               $(".line[data-id=" + checkIdRight + "]").attr("data-isSelected") == 1) {
                var checkIdColor = (row + 1) + "_" + (col);
                $(".box[data-id=" + checkIdColor + "]").css("opacity", 1);
                $(".box[data-id=" + checkIdColor + "]").css("background-color", player);
                result = true;
            }
            return result;

        }
    }
    else {
        if (col == 0) {
            var checkIdUp = (row) + "_" + (col + 2);
            var checkIdLeft = (row - 1) + "_" + (col + 1);
            var checkIdRight = (row + 1) + "_" + (col + 1);
            if ($(".line[data-id=" + checkIdUp + "]").attr("data-isSelected") == 1 &&
               $(".line[data-id=" + checkIdLeft + "]").attr("data-isSelected") == 1 &&
               $(".line[data-id=" + checkIdRight + "]").attr("data-isSelected") == 1) {
                var checkIdColor = (row) + "_" + (col + 1);
                $(".box[data-id=" + checkIdColor + "]").css("opacity", 1);
                $(".box[data-id=" + checkIdColor + "]").css("background-color", player);
                return true;
            }
            return false;
        }
        else if (col == tbCol * 2 + 1) {
            var checkIdUp = (row) + "_" + (col - 2);
            var checkIdLeft = (row - 1) + "_" + (col - 1);
            var checkIdRight = (row + 1) + "_" + (col - 1);
            if ($(".line[data-id=" + checkIdUp + "]").attr("data-isSelected") == 1 &&
               $(".line[data-id=" + checkIdLeft + "]").attr("data-isSelected") == 1 &&
               $(".line[data-id=" + checkIdRight + "]").attr("data-isSelected") == 1) {
                var checkIdColor = (row) + "_" + (col - 1);
                $(".box[data-id=" + checkIdColor + "]").css("opacity", 1);
                $(".box[data-id=" + checkIdColor + "]").css("background-color", player);
                return true;
            }
            return false;
        }
        else {
            var result = false;
            var checkIdUp = (row) + "_" + (col - 2);
            var checkIdLeft = (row - 1) + "_" + (col - 1);
            var checkIdRight = (row + 1) + "_" + (col - 1);
            if ($(".line[data-id=" + checkIdUp + "]").attr("data-isSelected") == 1 &&
               $(".line[data-id=" + checkIdLeft + "]").attr("data-isSelected") == 1 &&
               $(".line[data-id=" + checkIdRight + "]").attr("data-isSelected") == 1) {
                var checkIdColor = (row) + "_" + (col - 1);
                $(".box[data-id=" + checkIdColor + "]").css("opacity", 1);
                $(".box[data-id=" + checkIdColor + "]").css("background-color", player);

                result = true;
            }

            var checkIdUp = (row) + "_" + (col + 2);
            var checkIdLeft = (row - 1) + "_" + (col + 1);
            var checkIdRight = (row + 1) + "_" + (col + 1);
            if ($(".line[data-id=" + checkIdUp + "]").attr("data-isSelected") == 1 &&
               $(".line[data-id=" + checkIdLeft + "]").attr("data-isSelected") == 1 &&
               $(".line[data-id=" + checkIdRight + "]").attr("data-isSelected") == 1) {
                var checkIdColor = (row) + "_" + (col + 1);
                $(".box[data-id=" + checkIdColor + "]").css("opacity", 1);
                $(".box[data-id=" + checkIdColor + "]").css("background-color", player);
                result = true;
            }
            return result;

        }
    }
}
